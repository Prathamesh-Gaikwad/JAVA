public class Record
{
	String title;
	String descrip;
	String date;
	String status;
	
	Record(String title, String descrip, String date, String status)
	{
		this.title = title;
		this.descrip = descrip;
		this.date = date;
		this.status = status;
	}
}

